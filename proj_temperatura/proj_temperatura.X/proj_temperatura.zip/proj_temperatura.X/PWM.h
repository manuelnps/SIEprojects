

void PWMInit(void);
void PWMSetDutyCycle(float dutyCycle);
void PWMStart(void);

